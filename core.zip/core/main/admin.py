from django.contrib import admin

# Register your models here.
from .models import Product,Product2,Product3,Product4,Team,Glxavor,About,Special,Pox
# Register your models here.

admin.site.register(Product)
admin.site.register(Product2)
admin.site.register(Product3)
admin.site.register(Product4)
admin.site.register(Team)
admin.site.register(Glxavor)
admin.site.register(About)
admin.site.register(Special)
admin.site.register(Pox)
