from django.db import models

# Create your models here.

class Pox(models.Model):
    pox = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)

    def __str__(self):
        return self.pox

class Product(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    description = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    price = models.TextField(max_length=10, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='product/',null=True,blank=True)

    def __str__(self):
        return self.name
    
class Product2(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    description = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    price = models.TextField(max_length=10, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='product/',null=True,blank=True)

    def __str__(self):
        return self.name
    
class Product3(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    description = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    price = models.TextField(max_length=10, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='product/',null=True,blank=True)

    def __str__(self):
        return self.name
    
class Product4(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    description = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    price = models.TextField(max_length=10, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='product/',null=True,blank=True)

    def __str__(self):
        return self.name
    
    
class Team(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    description = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    insta =models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    twitter = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    linken=models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    facebook=models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='product/',null=True,blank=True)

    def __str__(self):
        return self.name
    
class Glxavor(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    name2 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name3 =models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name4 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name5=models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name6=models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name7 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    name8=models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    
    def __str__(self):
        return self.name
    


class About(models.Model):
    text = models.CharField(max_length=100,null=True,blank=True)
    text2 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    text3 =models.TextField(max_length=5000, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='about/',null=True,blank=True)
    image2 = models.ImageField(upload_to='about2/',null=True,blank=True)

    def __str__(self):
        return self.text
    
    
class Special(models.Model):
    text = models.CharField(max_length=100,null=True,blank=True)
    text2 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    text3 = models.TextField(max_length=255, default='Описание не указано',null=True,blank=True)
    text4 =models.TextField(max_length=5000, default='Описание не указано',null=True,blank=True)
    image = models.ImageField(upload_to='about/',null=True,blank=True)

    def __str__(self):
        return self.text