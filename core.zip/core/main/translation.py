from .models import Product,Product2,Product3,Product4,Team,Glxavor,About,Special,Pox
from modeltranslation.translator import register, TranslationOptions

@register(Product)
class ProductTranslationOptions(TranslationOptions):
    fields = ('name', 'description','price',)
    
@register(Product2)
class Product2TranslationOptions(TranslationOptions):
    fields = ('name', 'description','price',)
    
@register(Product3)
class Product3TranslationOptions(TranslationOptions):
    fields = ('name', 'description','price',)
    
@register(Product4)
class Product4TranslationOptions(TranslationOptions):
    fields = ('name', 'description','price',)
    
@register(Team)
class   TeamTranslationOptions(TranslationOptions):
    fields = ('name', 'description')
    
@register(Glxavor)
class   GlxavorTranslationOptions(TranslationOptions):
    fields = ('name', 'name2','name3','name4','name5','name6','name7','name8',)
    
@register(About)
class   AboutTranslationOptions(TranslationOptions):
    fields = ('text', 'text2','text3')

@register(Special)
class   SpecialTranslationOptions(TranslationOptions):
    fields = ('text', 'text2','text3','text4')
    
@register(Pox)
class   PoxTranslationOptions(TranslationOptions):
    fields = ('pox',)