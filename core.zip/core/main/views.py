from django.shortcuts import render,redirect
from .models  import Product,Product2,Product3,Product4,Team,Glxavor,About,Special,Pox
# Create your views here.

def index(request):
    product_list = Product.objects.all()
    product_list2 = Product2.objects.all()
    product_list3 = Product3.objects.all()
    product_list4 = Product4.objects.all()
    team_list=Team.objects.all()
    glxavor_list = Glxavor.objects.all()
    about_list = About.objects.all()
    special_list=Special.objects.all()
    pox_list = Pox.objects.all()
    return render(request,'Index.html',context={
        'product_list':product_list,
        'product_list2':product_list2,
        'product_list3':product_list3,
        'product_list4':product_list4,
        'team_list':team_list,
        'glxavor_list':glxavor_list,
        'about_list':about_list,
        'special_list':special_list,
        'pox_list':pox_list
    })
    